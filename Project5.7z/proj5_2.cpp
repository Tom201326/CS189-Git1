// This program illustrates pointers to class objects
// and structures as parameters of functions.
#include <iostream> 
#include <string> 
using namespace std;

// Person class
class Person
{
private:
	  string name;
	  int  age;
public:
	Person() 
	{ 
		name = "";
		age = 0;
	}
	Person(string name1, int age1)
	{
		name = name1;
		age = age1;
	}
	  int getAge() { return age; }
	  string getName() { return name; }
	  void setName(string name1) { name = name1; }
	  void setAge(int age1) { age = age1; }
};


// Prototypes
int lengthOfName(Person *p);

int main()
{
	int numberOfPeople{}, age;
	string name;

	// Ask the user for the number of people to process
	cout << "Please enter the number of people to process: ";
	cin >> numberOfPeople;

	Person* personArray = new Person[numberOfPeople];

	for (int i = 0; i < numberOfPeople; i++)
	{
		cout << "Enter the name of person " << i + 1 << ": ";
		cin.ignore();
		getline(cin, name);
		personArray[i].setName(name);

		cout << "Enter the age of person " << i + 1 << ": ";
		cin >> age;
		personArray[i].setAge(age);
	}

	// Create a Person object and find the length of the person's name
	for (int i = 0; i < numberOfPeople; i++)
	{
		cout << "The name " << personArray[i].getName()
			 << " has length " << lengthOfName(&personArray[i]) << endl;
	}

	delete[] personArray;
	personArray = nullptr;
	  
  	return 0; 
}

//******************************************************
// Returns the number of characters in a person's name *
//******************************************************
int lengthOfName(Person *p)
{
   string name = p->getName();
   return name.length();
}